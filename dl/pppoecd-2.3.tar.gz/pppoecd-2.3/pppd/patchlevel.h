/* $Id: patchlevel.h,v 1.1.1.4 2003/10/14 08:09:53 sparq Exp $ */

#define VERSION		"2.4.1"
#define DATE		"25 March 2001"
