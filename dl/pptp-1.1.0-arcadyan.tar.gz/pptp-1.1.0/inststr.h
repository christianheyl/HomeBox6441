/* inststr.h ..... change argv[0].
 *
 * $Id: inststr.h,v 1.1.1.1 2002/07/25 06:52:39 honor Exp $
 */

void inststr(int argc, char **argv, char **envp, char *src);
