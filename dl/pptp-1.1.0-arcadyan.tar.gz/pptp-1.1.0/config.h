/* text added by Makefile target config.h */
#define PPTP_LINUX_VERSION "1.1.0"
#define PPPD_BINARY "/usr/sbin/pppd"
