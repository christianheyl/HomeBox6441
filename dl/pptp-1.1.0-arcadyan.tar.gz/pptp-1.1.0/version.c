/* version.c ..... keep track of package version number. 
 *                 C. Scott Ananian <cananian@alumni.princeton.edu>
 *
 * $Id: version.c,v 1.1.1.1 2002/07/25 06:52:39 honor Exp $
 */

#include "config.h"
const char * version = "pptp-linux version " PPTP_LINUX_VERSION;
